'use client'

import Image from 'next/image'

export default function BrandingCustomization({ options = {}, onSelect, selectedLogo, selectedFont, selectedColors, selectedCharacter }) {
  const { logos = [], fonts = [], colors = [] } = options

  // Filter and add character-specific logos
  const getLogosForCharacter = () => {
    let availableLogos = [...logos]
    
    if (selectedCharacter) {
      switch (selectedCharacter.name) {
        case 'Chef Giuseppe':
          availableLogos = availableLogos.map(logo => {
            if (logo.id === 'Logotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/verologotipo-U2uz5pwAY0bEvWlikSl9BDAnkWe8bO.png'
              }
            }
            if (logo.id === 'Imagotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/veroimagotipo-L15eBev1WtJzMzJ4lSuZTIHrHbCWAZ.png'
              }
            }
            if (logo.id === 'Isotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/veroisotipo-NPLTHL7eSqTG2RqH75yT1pOIhGjnxK.png'
              }
            }
            return logo
          })
          break
        case 'Chef Pierre':
          availableLogos = availableLogos.map(logo => {
            if (logo.id === 'Logotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mirragelogotipo-2TYbdkpqVvepFpBCXfvI8Pf8hE3Ezy.png'
              }
            }
            if (logo.id === 'Imagotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mirrageimagotipo-PnBoOzkxTX5CUKJ6AvhIjT9rw7gIhD.png'
              }
            }
            if (logo.id === 'Isotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mirageisotipo-XN1zZD4OPzSpcW3fsUh4AJm9nwCZlW.png'
              }
            }
            return logo
          })
          break
        case 'Chef Lee':
          availableLogos = availableLogos.map(logo => {
            if (logo.id === 'Logotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/shirologotipo-kBKDw0gCuzlhynYErAGbxYePtbzX6s.png'
              }
            }
            if (logo.id === 'Imagotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/shiroimagotipo-ZSHLtQqjTXUta3jfbC301RCeEynrT0.png'
              }
            }
            if (logo.id === 'Isotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/shiroisotipo-nLB63vjWK6MbaxzfnzPNCakOnIUNhK.png'
              }
            }
            return logo
          })
          break
        case 'Chef Amy':
          availableLogos = availableLogos.map(logo => {
            if (logo.id === 'Logotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ashfirelogotipo-SGldtGHNjWk8wVnjDVJhI1VfclrBzi.png'
              }
            }
            if (logo.id === 'Isotipo') {
              return {
                ...logo,
                specialImage: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ashfireisotipo-LDNAjqEZnNXV0btoYZ5bRp4yFU8FqE.png'
              }
            }
            return logo
          })
          break
      }
    }
    
    return availableLogos
  }

  const availableLogos = getLogosForCharacter()

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">Logotipo</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {availableLogos.map((logo) => (
            <button
              key={logo.id}
              onClick={() => onSelect('logo', logo)}
              className={`p-4 border-2 ${
                selectedLogo?.id === logo.id ? 'border-[#E5007E] bg-white text-black' : 'border-white bg-black text-white'
              } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
            >
              <div className="relative w-full h-32 mb-2 bg-white flex items-center justify-center">
                <Image 
                  src={logo.specialImage || logo.image} 
                  alt={logo.name} 
                  layout="fill" 
                  objectFit="contain"
                  className="p-6"  
                />
              </div>
              <span className="uppercase font-bold text-sm">{logo.name}</span>
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">Tipografía</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {fonts.map((font) => (
            <button
              key={font.id}
              onClick={() => onSelect('font', font)}
              className={`p-4 border-2 ${
                selectedFont?.id === font.id ? 'border-[#E5007E] bg-white' : 'border-white bg-black'
              } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
            >
              <div className="relative w-full h-32 mb-2 bg-white flex items-center justify-center">
                <Image
                  src={font.image}
                  alt={font.name}
                  layout="fill"
                  objectFit="contain"
                  className="p-6"
                />
              </div>
              <p className="text-sm text-center mt-1">{font.name}</p>
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">Colores</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {colors.map((color) => (
            <button
              key={color.id}
              onClick={() => onSelect('colors', color)}
              className={`p-4 border-2 ${
                selectedColors?.id === color.id ? 'border-[#E5007E] bg-white' : 'border-white bg-black'
              } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
            >
              <div className="relative w-full h-32 mb-2 bg-white flex items-center justify-center">
                <Image 
                  src={color.image} 
                  alt={color.id} 
                  layout="fill" 
                  objectFit="contain"
                  className="p-6"
                />
              </div>
              <span className="uppercase font-bold text-sm">{color.id}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}