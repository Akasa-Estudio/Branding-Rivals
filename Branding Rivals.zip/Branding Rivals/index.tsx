'use client'

import { useState } from 'react'
import Image from 'next/image'

export default function CharacterSelection({ characters, onSelect }) {
  const [hoveredCharacter, setHoveredCharacter] = useState(null)

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {characters.map((character) => (
        <button
          key={character.id}
          onClick={() => onSelect(character)}
          onMouseEnter={() => setHoveredCharacter(character.id)}
          onMouseLeave={() => setHoveredCharacter(null)}
          className="bg-white text-black p-4 transform transition-all duration-300 ease-out hover:scale-105 focus:outline-none focus:ring-2 focus:ring-red-600 focus:ring-offset-2 focus:ring-offset-black relative group"
          style={{
            transform: hoveredCharacter === character.id ? 'rotateY(10deg) rotateX(5deg)' : 'rotateY(0) rotateX(0)',
            transition: 'transform 0.3s ease-out',
          }}
        >
          <div className="relative h-48 mb-4 overflow-hidden">
            <Image
              src={character.image}
              alt={character.name}
              layout="fill"
              objectFit="cover"
              className="filter grayscale group-hover:grayscale-0 transition-all duration-300"
            />
            <div 
              className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-70 transition-opacity duration-300"
            ></div>
          </div>
          <div className="text-left relative z-10">
            <h2 className="text-2xl font-bold mb-2 uppercase">{character.name}</h2>
            <p className="text-sm uppercase tracking-wider">{character.restaurantType}</p>
          </div>
          <div 
            className="absolute inset-0 bg-red-600 transform scale-y-0 group-hover:scale-y-100 transition-transform duration-300 origin-bottom"
            style={{ zIndex: -1 }}
          ></div>
        </button>
      ))}
    </div>
  )
}