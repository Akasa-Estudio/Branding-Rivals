import Image from 'next/image'

export default function BrandingCustomization({ options = {}, onSelect, selectedLogo, selectedFont, selectedColors }) {
  const { logos = [], fonts = [], colors = [] } = options

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">Logotipo</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {logos.map((logo) => (
            <button
              key={logo.id}
              onClick={() => onSelect('logo', logo)}
              className={`p-3 border-2 ${
                selectedLogo?.id === logo.id ? 'border-[#E5007E] bg-white' : 'border-white bg-black'
              } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
            >
              <Image src={logo.image} alt={logo.id} width={100} height={100} className="mb-2" />
              <span className="uppercase font-bold text-sm">{logo.id}</span>
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">Tipografía</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {fonts.map((font) => (
            <button
              key={font.id}
              onClick={() => onSelect('font', font)}
              className={`p-4 border-2 ${
                selectedFont?.id === font.id ? 'border-[#E5007E] bg-white' : 'border-white bg-black'
              } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
            >
              <div className="relative w-48 h-24 mb-2 bg-white">
                <Image
                  src={font.image}
                  alt={font.name}
                  layout="fill"
                  objectFit="cover"
                />
              </div>
              <p className="text-sm text-center mt-1">{font.name}</p>
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">Colores</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {colors.map((color) => (
            <button
              key={color.id}
              onClick={() => onSelect('colors', color)}
              className={`p-3 border-2 ${
                selectedColors?.id === color.id ? 'border-[#E5007E] bg-white' : 'border-white bg-black'
              } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
            >
              <Image src={color.image} alt={color.id} width={100} height={100} className="mb-2" />
              <span className="uppercase font-bold text-sm">{color.id}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}