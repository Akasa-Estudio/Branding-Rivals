'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import CharacterSelection from './components/CharacterSelection'
import BrandingCustomization from './components/BrandingCustomization'
import MockupGallery from './components/MockupGallery'

const characters = [
  { id: 1, name: 'Chef Ana', restaurantType: 'Cocina Fusión', image: '/placeholder.svg?height=200&width=200' },
  { id: 2, name: 'Chef Bruno', restaurantType: 'Pizzería Gourmet', image: '/placeholder.svg?height=200&width=200' },
  { id: 3, name: 'Chef Carla', restaurantType: 'Restaurante Vegano', image: '/placeholder.svg?height=200&width=200' },
  { id: 4, name: 'Chef David', restaurantType: 'Steakhouse', image: '/placeholder.svg?height=200&width=200' },
  { id: 5, name: 'Chef Elena', restaurantType: 'Sushi Bar', image: '/placeholder.svg?height=200&width=200' },
  { id: 6, name: 'Chef Fernando', restaurantType: 'Taquería Moderna', image: '/placeholder.svg?height=200&width=200' },
]

const brandingOptions = {
  logos: ['Logo1', 'Logo2', 'Logo3'],
  fonts: ['Font1', 'Font2', 'Font3'],
  colors: ['Colors1', 'Colors2', 'Colors3'],
}

export default function BrandingRivals() {
  const [step, setStep] = useState(0)
  const [selectedCharacter, setSelectedCharacter] = useState(null)
  const [selectedLogo, setSelectedLogo] = useState('')
  const [selectedFont, setSelectedFont] = useState('')
  const [selectedColors, setSelectedColors] = useState('')

  const handleCharacterSelect = (character) => {
    setSelectedCharacter(character)
    setStep(1)
  }

  const handleBrandingSelect = (type, option) => {
    switch (type) {
      case 'logo':
        setSelectedLogo(option)
        break
      case 'font':
        setSelectedFont(option)
        break
      case 'colors':
        setSelectedColors(option)
        break
    }
  }

  const handleNext = () => {
    if (step < 2 && selectedLogo && selectedFont && selectedColors) {
      setStep(step + 1)
    }
  }

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  const renderStep = () => {
    switch (step) {
      case 0:
        return <CharacterSelection characters={characters} onSelect={handleCharacterSelect} />
      case 1:
        return (
          <BrandingCustomization
            options={brandingOptions}
            onSelect={handleBrandingSelect}
            selectedLogo={selectedLogo}
            selectedFont={selectedFont}
            selectedColors={selectedColors}
          />
        )
      case 2:
        return (
          <MockupGallery
            character={selectedCharacter}
            logo={selectedLogo}
            font={selectedFont}
            colors={selectedColors}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-8">Branding Rivals</h1>
      {renderStep()}
      <div className="flex justify-between mt-8">
        <button
          onClick={handleBack}
          disabled={step === 0}
          className="flex items-center px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          <ArrowLeft className="mr-2" />
          Atrás
        </button>
        {step < 2 && (
          <button
            onClick={handleNext}
            disabled={step === 1 && (!selectedLogo || !selectedFont || !selectedColors)}
            className="flex items-center px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            Siguiente
            <ArrowRight className="ml-2" />
          </button>
        )}
      </div>
    </div>
  )
}