import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  const mockups = [
    { id: 1, name: 'Menú', image: '/mockups/menu.jpg' },
    { id: 2, name: 'Tarjeta de visita', image: '/mockups/business-card.jpg' },
    { id: 3, name: 'Señalización', image: '/mockups/signage.jpg' },
    { id: 4, name: 'Empaques', image: '/mockups/packaging.jpg' },
  ]

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Galería de mockups</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {mockups.map((mockup) => (
          <div key={mockup.id} className="bg-white p-4 rounded-lg shadow-md">
            <Image src={mockup.image} alt={mockup.name} width={400} height={300} className="rounded-lg mb-4" />
            <h3 className="text-xl font-semibold mb-2">{mockup.name}</h3>
            <p className="text-gray-600">
              Logotipo: {logo}, Tipografía: {font}, Colores: {colors}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}