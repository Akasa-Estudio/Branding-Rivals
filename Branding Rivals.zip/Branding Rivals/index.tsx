export default function BrandingCustomization({ options, onSelect, selectedLogo, selectedFont, selectedColors }) {
  return (
    <div className="mb-8">
      <h2 className="text-2xl font-semibold mb-4">Personaliza tu marca</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-xl mb-2">Logotipo</h3>
          <div className="grid grid-cols-2 gap-2">
            {options.logos.map((logo) => (
              <button
                key={logo}
                className={`p-2 border rounded ${selectedLogo === logo ? 'bg-blue-500 text-white' : 'bg-white'}`}
                onClick={() => onSelect('logo', logo)}
              >
                {logo}
              </button>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-xl mb-2">Tipografía</h3>
          <div className="grid grid-cols-2 gap-2">
            {options.fonts.map((font) => (
              <button
                key={font}
                className={`p-2 border rounded ${selectedFont === font ? 'bg-blue-500 text-white' : 'bg-white'}`}
                onClick={() => onSelect('font', font)}
              >
                {font}
              </button>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-xl mb-2">Paleta de colores</h3>
          <div className="grid grid-cols-2 gap-2">
            {options.colors.map((color) => (
              <button
                key={color}
                className={`p-2 border rounded ${selectedColors === color ? 'bg-blue-500 text-white' : 'bg-white'}`}
                onClick={() => onSelect('colors', color)}
              >
                {color}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}