'use client'

import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  const mockups = [
    {
      id: 1,
      title: 'Business Card',
      image: '/placeholder.svg?height=200&width=300&text=Business+Card+Mockup'
    },
    {
      id: 2,
      title: 'Menu Design',
      image: '/placeholder.svg?height=200&width=300&text=Menu+Design+Mockup'
    },
    {
      id: 3,
      title: 'Storefront',
      image: '/placeholder.svg?height=200&width=300&text=Storefront+Mockup'
    },
    {
      id: 4,
      title: 'Social Media',
      image: '/placeholder.svg?height=200&width=300&text=Social+Media+Mockup'
    }
  ]

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
        Mockup Gallery
      </h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg">
          <h3 className="text-black text-lg font-bold mb-2">Selected Character</h3>
          <div className="relative h-40 w-full">
            <Image
              src={character?.image || '/placeholder.svg?height=160&width=160&text=No+Character'}
              alt={character?.name || 'No character selected'}
              layout="fill"
              objectFit="contain"
            />
          </div>
          <p className="text-black mt-2">{character?.name || 'No character selected'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg">
          <h3 className="text-black text-lg font-bold mb-2">Selected Branding</h3>
          <div className="grid gap-2">
            <div className="relative h-20 bg-gray-100 rounded">
              <Image
                src={logo?.image || '/placeholder.svg?height=80&width=80&text=No+Logo'}
                alt="Selected Logo"
                layout="fill"
                objectFit="contain"
              />
            </div>
            <div className="relative h-20 bg-gray-100 rounded">
              <Image
                src={font?.image || '/placeholder.svg?height=80&width=80&text=No+Font'}
                alt="Selected Font"
                layout="fill"
                objectFit="contain"
              />
            </div>
            <div className="relative h-20 bg-gray-100 rounded">
              <Image
                src={colors?.image || '/placeholder.svg?height=80&width=80&text=No+Colors'}
                alt="Selected Colors"
                layout="fill"
                objectFit="contain"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-xl font-bold mb-4 uppercase">Preview Mockups</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {mockups.map((mockup) => (
            <div key={mockup.id} className="bg-white p-3 rounded-lg transform hover:scale-105 transition-transform">
              <div className="relative h-48 w-full mb-2">
                <Image
                  src={mockup.image}
                  alt={mockup.title}
                  layout="fill"
                  objectFit="cover"
                  className="rounded"
                />
              </div>
              <h4 className="text-black font-bold text-center">{mockup.title}</h4>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}