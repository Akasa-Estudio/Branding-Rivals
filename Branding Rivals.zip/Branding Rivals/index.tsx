import Image from 'next/image'

export default function CharacterSelection({ characters, onSelect }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {characters.map((character) => (
        <div
          key={character.id}
          className="bg-white p-4 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => onSelect(character)}
        >
          <Image
            src={`/characters/${character.id}.jpg`}
            alt={character.name}
            width={200}
            height={200}
            className="rounded-full mx-auto mb-4"
          />
          <h2 className="text-xl font-semibold text-center">{character.name}</h2>
          <p className="text-center text-gray-600">{character.restaurantType}</p>
        </div>
      ))}
    </div>
  )
}