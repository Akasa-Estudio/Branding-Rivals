export default function BrandingCustomization({ options = {}, onSelect, selectedLogo, selectedFont, selectedColors }) {
  const { logos = [], fonts = [], colors = [] } = options

  return (
    <div className="space-y-12">
      <div>
        <h2 className="text-3xl font-bold mb-4 uppercase bg-red-600 inline-block px-2 transform -skew-x-12">Logotipo</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {logos.map((logo) => (
            <button
              key={logo}
              onClick={() => onSelect('logo', logo)}
              className={`p-4 border-4 ${
                selectedLogo === logo ? 'border-red-600 bg-white text-black' : 'border-white bg-black text-white'
              } uppercase font-bold text-xl hover:bg-white hover:text-black transition-colors`}
            >
              {logo}
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-3xl font-bold mb-4 uppercase bg-red-600 inline-block px-2 transform -skew-x-12">Tipografía</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {fonts.map((font) => (
            <button
              key={font}
              onClick={() => onSelect('font', font)}
              className={`p-4 border-4 ${
                selectedFont === font ? 'border-red-600 bg-white text-black' : 'border-white bg-black text-white'
              } uppercase font-bold text-xl hover:bg-white hover:text-black transition-colors`}
            >
              {font}
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-3xl font-bold mb-4 uppercase bg-red-600 inline-block px-2 transform -skew-x-12">Colores</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {colors.map((color) => (
            <button
              key={color}
              onClick={() => onSelect('colors', color)}
              className={`p-4 border-4 ${
                selectedColors === color ? 'border-red-600 bg-white text-black' : 'border-white bg-black text-white'
              } uppercase font-bold text-xl hover:bg-white hover:text-black transition-colors`}
            >
              {color}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}