import Image from 'next/image'

export default function CharacterSelection({ characters, onSelect }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {characters.map((character) => (
        <button
          key={character.id}
          onClick={() => onSelect(character)}
          className="bg-white text-black p-4 transform hover:skew-y-3 transition-transform focus:outline-none focus:ring-2 focus:ring-red-600 focus:ring-offset-2 focus:ring-offset-black"
        >
          <div className="relative h-48 mb-4 overflow-hidden">
            <Image
              src={character.image}
              alt={character.name}
              layout="fill"
              objectFit="cover"
              className="filter grayscale hover:grayscale-0 transition-all duration-300"
            />
          </div>
          <div className="text-left">
            <h2 className="text-2xl font-bold mb-2 uppercase">{character.name}</h2>
            <p className="text-sm uppercase tracking-wider">{character.restaurantType}</p>
          </div>
        </button>
      ))}
    </div>
  )
}