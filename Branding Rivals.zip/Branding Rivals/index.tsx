'use client'

import Image from 'next/image'

interface Character {
  id: number
  name: string
  restaurantType: string
  description: string
  image: string
}

interface CharacterSelectionProps {
  characters: Character[]
  onSelect: (character: Character) => void
  selectedCharacter: Character | null
}

export default function CharacterSelection({ characters, onSelect, selectedCharacter }: CharacterSelectionProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
        Selecciona tu Chef
      </h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {characters.map((character) => (
          <button
            key={character.id}
            onClick={() => onSelect(character)}
            className={`p-4 border-2 ${
              selectedCharacter?.id === character.id ? 'border-[#E5007E] bg-white text-black' : 'border-white'
            } flex flex-col items-center justify-center hover:bg-white hover:text-black transition-colors`}
          >
            <div className="relative w-full aspect-square mb-2">
              <Image
                src={character.image}
                alt={character.name}
                layout="fill"
                objectFit="cover"
              />
            </div>
            <h3 className="font-bold text-sm">{character.name}</h3>
            <p className="text-xs">{character.restaurantType}</p>
          </button>
        ))}
      </div>
    </div>
  )
}