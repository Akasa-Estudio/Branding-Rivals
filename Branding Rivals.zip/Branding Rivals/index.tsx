'use client'

import { useState } from 'react'
import Image from 'next/image'

export default function CharacterSelection({ characters = [], onSelect, selectedCharacter }) {
  const [hoveredCharacter, setHoveredCharacter] = useState(null)

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
        Selecciona tu Chef
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {characters.map((character) => (
          <button
            key={character.id}
            onClick={() => onSelect(character)}
            onMouseEnter={() => setHoveredCharacter(character.id)}
            onMouseLeave={() => setHoveredCharacter(null)}
            className={`bg-black p-4 border-2 ${
              selectedCharacter?.id === character.id ? 'border-[#E5007E]' : 'border-white'
            } transform transition-all duration-300 ease-out hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[#E5007E] focus:ring-offset-2 focus:ring-offset-black relative group`}
          >
            <div className="relative h-48 mb-4 overflow-hidden">
              <Image
                src={character.image}
                alt={character.name}
                layout="fill"
                objectFit="cover"
                className="filter grayscale group-hover:grayscale-0 transition-all duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-50 group-hover:opacity-30 transition-opacity" />
            </div>
            <div className="text-left relative z-10">
              <h3 className="text-xl font-bold mb-1">{character.name}</h3>
              <p className="text-lg font-bold text-[#E5007E]">{character.restaurantType}</p>
              <p className="text-sm text-gray-400">{character.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}