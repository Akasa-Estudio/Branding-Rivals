'use client'

import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  // This is a placeholder component. In a real application, you would generate
  // or retrieve actual mockups based on the selected options.
  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
        Mockup Gallery
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg">
          <h3 className="text-black text-lg font-bold mb-2">Selected Character</h3>
          <div className="relative h-40 w-full">
            <Image
              src={character?.image || '/placeholder.svg?height=160&width=160&text=No+Character'}
              alt={character?.name || 'No character selected'}
              layout="fill"
              objectFit="contain"
            />
          </div>
          <p className="text-black mt-2">{character?.name || 'No character selected'}</p>
        </div>
        <div className="bg-white p-4 rounded-lg">
          <h3 className="text-black text-lg font-bold mb-2">Selected Branding</h3>
          <div className="space-y-2">
            <p className="text-black">Logo: {logo?.id || 'None'}</p>
            <p className="text-black">Font: {font?.name || 'None'}</p>
            <p className="text-black">Colors: {colors?.id || 'None'}</p>
          </div>
        </div>
      </div>
      <p className="text-center text-lg">
        In a full application, this section would display generated mockups based on your selections.
      </p>
    </div>
  )
}