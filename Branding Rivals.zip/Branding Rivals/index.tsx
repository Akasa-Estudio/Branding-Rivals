export default function BrandingRivals() {
  // ... (código anterior omitido para brevedad)

  return (
    <div className="min-h-screen bg-black text-white font-mono">
      <div className="px-4 py-6">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-6 uppercase tracking-tighter">
          <span className="bg-white text-black px-2 transform -skew-x-12 inline-block">Branding</span>
          <span className="bg-red-600 px-2 transform skew-x-12 inline-block ml-2">Rivals</span>
        </h1>
        {/* ... (resto del código) */}
      </div>
    </div>
  )
}