'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import Image from 'next/image'
import CharacterSelection from './components/CharacterSelection'
import BrandingCustomization from './components/BrandingCustomization'
import MockupGallery from './components/MockupGallery'

const characters = [
  { 
    id: 1, 
    name: 'Chef Amy', 
    restaurantType: 'American Diner', 
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1-OAZtXjeT2YBVegZNEueQdMGAwRyM6e.png'
  },
  { 
    id: 2, 
    name: 'Chef Bear', 
    restaurantType: 'Comfort Food', 
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/2-nG3TJYtaFoXUdXxwixGcJi2FbjvxXC.png'
  },
  { 
    id: 3, 
    name: 'Chef Lee', 
    restaurantType: 'Asian Fusion', 
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3-cIWWXMnYZfSvsBvcfBq62CUr0R0Qna.png'
  },
  { 
    id: 4, 
    name: 'Chef Marco', 
    restaurantType: 'Trattoria Italiana', 
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4-ohXycnlVqkLMvZXm17vcTnX43hlwI4.png'
  },
  { 
    id: 5, 
    name: 'Chef Pierre', 
    restaurantType: 'Cocina Creativa', 
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5-GWukBguPugwfpEEmbPTtROiH7ShlKy.png'
  },
  { 
    id: 6, 
    name: 'Chef Giuseppe', 
    restaurantType: 'Pizzería Gourmet', 
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/6-zKwsbAD63AILcqQ5xfBSfoqcJk6eiB.png'
  },
]

const brandingOptions = {
  logos: [
    { id: 'Logo1', image: '/placeholder.svg?height=100&width=100&text=Logo1' },
    { id: 'Logo2', image: '/placeholder.svg?height=100&width=100&text=Logo2' },
    { id: 'Logo3', image: '/placeholder.svg?height=100&width=100&text=Logo3' },
  ],
  fonts: [
    { id: 'Font1', image: '/placeholder.svg?height=100&width=100&text=Font1' },
    { id: 'Font2', image: '/placeholder.svg?height=100&width=100&text=Font2' },
    { id: 'Font3', image: '/placeholder.svg?height=100&width=100&text=Font3' },
  ],
  colors: [
    { id: 'Colors1', image: '/placeholder.svg?height=100&width=100&text=Colors1' },
    { id: 'Colors2', image: '/placeholder.svg?height=100&width=100&text=Colors2' },
    { id: 'Colors3', image: '/placeholder.svg?height=100&width=100&text=Colors3' },
  ],
}

export default function BrandingRivals() {
  const [step, setStep] = useState(0)
  const [selectedCharacter, setSelectedCharacter] = useState(null)
  const [selectedLogo, setSelectedLogo] = useState(null)
  const [selectedFont, setSelectedFont] = useState(null)
  const [selectedColors, setSelectedColors] = useState(null)

  const handleCharacterSelect = (character) => {
    setSelectedCharacter(character)
    setStep(1)
  }

  const handleBrandingSelect = (type, option) => {
    switch (type) {
      case 'logo':
        setSelectedLogo(option)
        break
      case 'font':
        setSelectedFont(option)
        break
      case 'colors':
        setSelectedColors(option)
        break
    }
  }

  const handleNext = () => {
    if (step < 2 && selectedLogo && selectedFont && selectedColors) {
      setStep(step + 1)
    }
  }

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  const renderStep = () => {
    switch (step) {
      case 0:
        return <CharacterSelection characters={characters} onSelect={handleCharacterSelect} />
      case 1:
        return (
          <BrandingCustomization
            options={brandingOptions}
            onSelect={handleBrandingSelect}
            selectedLogo={selectedLogo}
            selectedFont={selectedFont}
            selectedColors={selectedColors}
          />
        )
      case 2:
        return (
          <MockupGallery
            character={selectedCharacter}
            logo={selectedLogo}
            font={selectedFont}
            colors={selectedColors}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-black text-white font-mono">
      <div className="px-4 py-6">
        <div className="flex justify-center mb-8">
          <div className="relative w-full max-w-[300px] sm:max-w-[400px] aspect-[3/1]">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/branding%20rivals-g9fDorFwQ60xBwOokTD1BNer0rkV1G.png"
              alt="Branding Rivals"
              layout="fill"
              objectFit="contain"
              priority
            />
          </div>
        </div>
        <div className="border-4 border-white p-4 sm:p-6">
          {renderStep()}
        </div>
        <div className="flex justify-between mt-6">
          <button
            onClick={handleBack}
            disabled={step === 0}
            className="flex items-center px-3 py-2 bg-white text-black font-bold uppercase text-sm disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transform hover:skew-x-12 transition-transform"
          >
            <ArrowLeft className="mr-1 w-4 h-4" />
            Atrás
          </button>
          {step < 2 && (
            <button
              onClick={handleNext}
              disabled={step === 1 && (!selectedLogo || !selectedFont || !selectedColors)}
              className="flex items-center px-3 py-2 bg-[#E5007E] text-white font-bold uppercase text-sm disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transform hover:-skew-x-12 transition-transform"
            >
              Siguiente
              <ArrowRight className="ml-1 w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}