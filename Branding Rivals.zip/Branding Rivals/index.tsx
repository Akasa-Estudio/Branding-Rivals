'use client'

import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  const mockups = [
    { id: 1, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup1-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Menú digital' },
    { id: 2, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup2-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Tarjeta de visita' },
    { id: 3, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup3-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Página web' },
    { id: 4, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup4-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Redes sociales' },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
          Selected Branding
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <h3 className="text-black font-bold mb-2">Character</h3>
            {character && (
              <div className="relative w-full h-32">
                <Image
                  src={character.image}
                  alt={character.name}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h3 className="text-black font-bold mb-2">Logo</h3>
            {logo && (
              <div className="relative w-full h-32">
                <Image
                  src={logo.specialImage || logo.image}
                  alt={logo.name}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h3 className="text-black font-bold mb-2">Font</h3>
            {font && (
              <div className="relative w-full h-32">
                <Image
                  src={font.image}
                  alt={font.name}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h3 className="text-black font-bold mb-2">Colors</h3>
            {colors && (
              <div className="relative w-full h-32">
                <Image
                  src={colors.image}
                  alt={colors.id}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
          Preview Mockups
        </h2>
        <div className="grid grid-cols-2 gap-4">
          {mockups.map((mockup) => (
            <div key={mockup.id} className="bg-white p-4 rounded-lg">
              <div className="relative w-full" style={{ paddingBottom: '75%' }}>
                <Image
                  src={mockup.image}
                  alt={`Mockup ${mockup.id}`}
                  layout="fill"
                  objectFit="cover"
                  className="rounded-lg"
                />
              </div>
              <p className="text-black font-bold mt-2">{mockup.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}