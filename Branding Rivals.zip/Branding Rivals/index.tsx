'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import Image from 'next/image'
import CharacterSelection from '../components/CharacterSelection'
import BrandingCustomization from '../components/BrandingCustomization'
import MockupGallery from '../components/MockupGallery'

// ... rest of the code remains the same