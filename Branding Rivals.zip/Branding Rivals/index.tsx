import Image from 'next/image'

export default function CharacterSelection({ characters, onSelect }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {characters.map((character) => (
        <button
          key={character.id}
          onClick={() => onSelect(character)}
          className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <Image
            src={character.image}
            alt={character.name}
            width={200}
            height={200}
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <h2 className="text-xl font-semibold mb-2">{character.name}</h2>
            <p className="text-gray-600">{character.restaurantType}</p>
          </div>
        </button>
      ))}
    </div>
  )
}