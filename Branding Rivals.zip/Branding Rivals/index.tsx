'use client'

import { useState } from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import Image from 'next/image'
import CharacterSelection from '@/components/CharacterSelection'
import BrandingCustomization from '@/components/BrandingCustomization'
import MockupGallery from '@/components/MockupGallery'

const characters = [
  { 
    id: 1, 
    name: 'Chef Amy', 
    restaurantType: 'Ashfire',
    description: 'American Diner',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1-OAZtXjeT2YBVegZNEueQdMGAwRyM6e.png'
  },
  { 
    id: 2, 
    name: 'Chef Bear', 
    restaurantType: 'Comfort Food',
    description: 'Comfort Food',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/2-nG3TJYtaFoXUdXxwixGcJi2FbjvxXC.png'
  },
  { 
    id: 3, 
    name: 'Chef Lee', 
    restaurantType: 'Shiro',
    description: 'Asian Fusion',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3-cIWWXMnYZfSvsBvcfBq62CUr0R0Qna.png'
  },
  { 
    id: 4, 
    name: 'Chef Marco', 
    restaurantType: 'Trattoria Italiana',
    description: 'Italian Restaurant',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4-ohXycnlVqkLMvZXm17vcTnX43hlwI4.png'
  },
  { 
    id: 5, 
    name: 'Chef Pierre', 
    restaurantType: 'Mirage',
    description: 'Cocina Creativa',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5-GWukBguPugwfpEEmbPTtROiH7ShlKy.png'
  },
  { 
    id: 6, 
    name: 'Chef Giuseppe', 
    restaurantType: 'Vero',
    description: 'Pizzería Gourmet',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/6-zKwsbAD63AILcqQ5xfBSfoqcJk6eiB.png'
  },
]

const brandingOptions = {
  logos: [
    { 
      id: 'Logotipo', 
      name: 'Logotipo',
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logotipo-0K3dkyfKhBsEyskZ53hicfIdi2N3pm.png' 
    },
    { 
      id: 'Imagotipo', 
      name: 'Imagotipo',
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/imagotipo-RcRInbG6W95tzn6pLsYx183YNRsCXJ.png' 
    },
    { 
      id: 'Isotipo', 
      name: 'Isotipo',
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/isotipo-UutR43m67ieqY9Qb9KPQDbnK5Aloxo.png' 
    },
  ],
  fonts: [
    { 
      id: 'Crimsom', 
      name: 'Crimsom',
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/texto2-luBpdEH4NTcoSgedKcYzvAbaIICPQh.png' 
    },
    { 
      id: 'Lato', 
      name: 'Lato',
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/texto3-TofiWlBRmCqe5gh6mPVbB4UIHkApJT.png' 
    },
    { 
      id: 'Monsieur', 
      name: 'Monsieur',
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/texto-yAO4zqEoEpYpKVojIlBJ3eWhuL3Ltg.png' 
    },
  ],
  colors: [
    { 
      id: 'Colors1', 
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/color-MXNkBzHolTRlzhuIrEVYNPM3ovwWTj.png'
    },
    { 
      id: 'Colors2', 
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/color2-O4aTkwuSUOYvCUX0zEqofU3YBNbbdA.png'
    },
    { 
      id: 'Colors3', 
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/color3-07TVKiqQOhjX9rlcV2rARNeZmvaJn2.png'
    },
  ],
}

export default function BrandingRivals() {
  const [step, setStep] = useState(0)
  const [selectedCharacter, setSelectedCharacter] = useState(null)
  const [selectedLogo, setSelectedLogo] = useState(null)
  const [selectedFont, setSelectedFont] = useState(null)
  const [selectedColors, setSelectedColors] = useState(null)

  const handleCharacterSelect = (character) => {
    setSelectedCharacter(character)
    setStep(1)
  }

  const handleBrandingSelect = (type, option) => {
    switch (type) {
      case 'logo':
        setSelectedLogo(option)
        break
      case 'font':
        setSelectedFont(option)
        break
      case 'colors':
        setSelectedColors(option)
        break
    }
  }

  const handleNext = () => {
    if (step < 2 && ((step === 0 && selectedCharacter) || (step === 1 && selectedLogo && selectedFont && selectedColors))) {
      setStep(step + 1)
    }
  }

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  return (
    <div className="min-h-screen bg-black text-white font-mono">
      <div className="px-4 py-6">
        <div className="flex justify-center mb-8">
          <div className="relative w-full max-w-[300px] sm:max-w-[400px] aspect-[3/1]">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/branding%20rivals-g9fDorFwQ60xBwOokTD1BNer0rkV1G.png"
              alt="Branding Rivals"
              layout="fill"
              objectFit="contain"
              priority
            />
          </div>
        </div>
        <div className="border-4 border-white p-4 sm:p-6">
          {step === 0 && (
            <CharacterSelection 
              characters={characters} 
              onSelect={handleCharacterSelect} 
              selectedCharacter={selectedCharacter}
            />
          )}
          {step === 1 && (
            <BrandingCustomization
              options={brandingOptions}
              onSelect={handleBrandingSelect}
              selectedLogo={selectedLogo}
              selectedFont={selectedFont}
              selectedColors={selectedColors}
              selectedCharacter={selectedCharacter}
            />
          )}
          {step === 2 && (
            <MockupGallery
              character={selectedCharacter}
              logo={selectedLogo}
              font={selectedFont}
              colors={selectedColors}
            />
          )}
        </div>
        <div className="flex justify-between mt-6">
          <button
            onClick={handleBack}
            disabled={step === 0}
            className="flex items-center px-3 py-2 bg-white text-black font-bold uppercase text-sm disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transform hover:skew-x-12 transition-transform"
          >
            <ArrowLeft className="mr-1 w-4 h-4" />
            Atrás
          </button>
          {step < 2 && (
            <button
              onClick={handleNext}
              disabled={
                (step === 0 && !selectedCharacter) || 
                (step === 1 && (!selectedLogo || !selectedFont || !selectedColors))
              }
              className="flex items-center px-3 py-2 bg-[#E5007E] text-white font-bold uppercase text-sm disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed transform hover:-skew-x-12 transition-transform"
            >
              Siguiente
              <ArrowRight className="ml-1 w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}