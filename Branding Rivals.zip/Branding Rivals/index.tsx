import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  const mockups = [
    { id: 1, name: 'Menú', image: '/placeholder.svg?height=300&width=400' },
    { id: 2, name: 'Tarjeta', image: '/placeholder.svg?height=300&width=400' },
    { id: 3, name: 'Señal', image: '/placeholder.svg?height=300&width=400' },
    { id: 4, name: 'Empaque', image: '/placeholder.svg?height=300&width=400' },
  ]

  if (!character) {
    return <div className="text-center text-xl">No character selected</div>
  }

  return (
    <div>
      <h2 className="text-2xl sm:text-3xl font-bold mb-4 uppercase bg-red-600 inline-block px-2 transform -skew-x-12">
        Mockups: {character.name}
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {mockups.map((mockup) => (
          <div key={mockup.id} className="bg-white text-black p-3 transform hover:rotate-1 transition-transform">
            <div className="relative h-40 mb-3 overflow-hidden">
              <Image
                src={mockup.image}
                alt={mockup.name}
                layout="fill"
                objectFit="cover"
                className="filter grayscale hover:grayscale-0 transition-all duration-300"
              />
            </div>
            <h3 className="text-xl font-bold mb-1 uppercase">{mockup.name}</h3>
            <div className="flex justify-between items-center">
              <div className="flex space-x-2">
                {logo && <Image src={logo.image} alt={logo.id} width={30} height={30} />}
                {font && <Image src={font.image} alt={font.id} width={30} height={30} />}
                {colors && <Image src={colors.image} alt={colors.id} width={30} height={30} />}
              </div>
              <p className="text-xs uppercase tracking-wider">
                <span className="font-bold">Logo:</span> {logo?.id || 'N/A'} |{' '}
                <span className="font-bold">Tipo:</span> {font?.id || 'N/A'} |{' '}
                <span className="font-bold">Color:</span> {colors?.id || 'N/A'}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}