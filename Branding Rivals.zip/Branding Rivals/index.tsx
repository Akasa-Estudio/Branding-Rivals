export default function BrandingCustomization({ options, onSelect, selectedLogo, selectedFont, selectedColors }) {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold mb-4">Selecciona el logotipo</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {options.logos.map((logo) => (
            <button
              key={logo}
              onClick={() => onSelect('logo', logo)}
              className={`p-4 border rounded-lg ${
                selectedLogo === logo ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-100'
              }`}
            >
              {logo}
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-semibold mb-4">Selecciona la tipografía</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {options.fonts.map((font) => (
            <button
              key={font}
              onClick={() => onSelect('font', font)}
              className={`p-4 border rounded-lg ${
                selectedFont === font ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-100'
              }`}
            >
              {font}
            </button>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-semibold mb-4">Selecciona la paleta de colores</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {options.colors.map((color) => (
            <button
              key={color}
              onClick={() => onSelect('colors', color)}
              className={`p-4 border rounded-lg ${
                selectedColors === color ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-100'
              }`}
            >
              {color}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}