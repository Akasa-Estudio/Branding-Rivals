'use client'

import { useState } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function MockupGallery({ character, logo, font, colors }) {
  const [currentMockup, setCurrentMockup] = useState(0)

  const mockups = [
    { id: 1, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup1-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Menú digital' },
    { id: 2, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup2-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Tarjeta de visita' },
    { id: 3, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup3-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Local' },
    { id: 4, image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mockup4-Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5Ue5.jpg', description: 'Redes sociales' },
  ]

  const nextMockup = () => {
    setCurrentMockup((prev) => (prev + 1) % mockups.length)
  }

  const prevMockup = () => {
    setCurrentMockup((prev) => (prev - 1 + mockups.length) % mockups.length)
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
          Selected Branding
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-lg">
            <h3 className="text-black font-bold mb-4">Character</h3>
            {character && (
              <div className="relative w-full h-48">
                <Image
                  src={character.image}
                  alt={character.name}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
          <div className="bg-white p-6 rounded-lg">
            <h3 className="text-black font-bold mb-4">Logo</h3>
            {logo && (
              <div className="relative w-full h-48">
                <Image
                  src={logo.specialImage || logo.image}
                  alt={logo.name}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
          <div className="bg-white p-6 rounded-lg">
            <h3 className="text-black font-bold mb-4">Font</h3>
            {font && (
              <div className="relative w-full h-48">
                <Image
                  src={font.image}
                  alt={font.name}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
          <div className="bg-white p-6 rounded-lg">
            <h3 className="text-black font-bold mb-4">Colors</h3>
            {colors && (
              <div className="relative w-full h-48">
                <Image
                  src={colors.image}
                  alt={colors.id}
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </div>
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
          Preview Mockups
        </h2>
        <div className="relative">
          <div className="bg-white p-4 rounded-lg">
            <div className="relative w-full" style={{ paddingBottom: '75%' }}>
              <Image
                src={mockups[currentMockup].image}
                alt={`Mockup ${mockups[currentMockup].id}`}
                layout="fill"
                objectFit="cover"
                className="rounded-lg"
              />
            </div>
            <p className="text-black font-bold mt-4 text-center">{mockups[currentMockup].description}</p>
          </div>
          <button
            onClick={prevMockup}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 p-2 rounded-full text-white hover:bg-opacity-75 transition-all"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={nextMockup}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 p-2 rounded-full text-white hover:bg-opacity-75 transition-all"
          >
            <ChevronRight size={24} />
          </button>
        </div>
        <div className="flex justify-center mt-4">
          {mockups.map((mockup, index) => (
            <button
              key={mockup.id}
              onClick={() => setCurrentMockup(index)}
              className={`w-3 h-3 rounded-full mx-1 ${
                index === currentMockup ? 'bg-[#E5007E]' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}