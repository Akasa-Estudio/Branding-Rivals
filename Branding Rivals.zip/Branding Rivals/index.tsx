import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  const mockups = [
    { id: 1, name: 'Menú', image: '/placeholder.svg?height=300&width=400' },
    { id: 2, name: 'Tarjeta de visita', image: '/placeholder.svg?height=300&width=400' },
    { id: 3, name: 'Señalización', image: '/placeholder.svg?height=300&width=400' },
    { id: 4, name: 'Empaques', image: '/placeholder.svg?height=300&width=400' },
  ]

  return (
    <div>
      <h2 className="text-4xl font-bold mb-8 uppercase bg-red-600 inline-block px-2 transform -skew-x-12">
        Galería de mockups para {character.name}
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {mockups.map((mockup) => (
          <div key={mockup.id} className="bg-white text-black p-4 transform hover:rotate-1 transition-transform">
            <div className="relative h-48 mb-4 overflow-hidden">
              <Image
                src={mockup.image}
                alt={mockup.name}
                layout="fill"
                objectFit="cover"
                className="filter grayscale hover:grayscale-0 transition-all duration-300"
              />
            </div>
            <h3 className="text-2xl font-bold mb-2 uppercase">{mockup.name}</h3>
            <p className="text-sm uppercase tracking-wider">
              <span className="font-bold">Logo:</span> {logo} |{' '}
              <span className="font-bold">Tipografía:</span> {font} |{' '}
              <span className="font-bold">Colores:</span> {colors}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}