'use client'

import Image from 'next/image'

export default function MockupGallery({ character, logo, font, colors }) {
  const mockups = [
    {
      id: 1,
      title: 'Business Card',
      description: 'Tarjeta de presentación con el nuevo diseño de marca',
      image: '/placeholder.svg?height=200&width=300&text=Business+Card+Mockup'
    },
    {
      id: 2,
      title: 'Menu Design',
      description: 'Diseño de menú que incorpora la nueva identidad visual',
      image: '/placeholder.svg?height=200&width=300&text=Menu+Design+Mockup'
    },
    {
      id: 3,
      title: 'Storefront',
      description: 'Vista previa de la fachada del restaurante con la nueva marca',
      image: '/placeholder.svg?height=200&width=300&text=Storefront+Mockup'
    },
    {
      id: 4,
      title: 'Social Media',
      description: 'Ejemplos de posts en redes sociales con el nuevo branding',
      image: '/placeholder.svg?height=200&width=300&text=Social+Media+Mockup'
    }
  ]

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold mb-3 uppercase bg-[#E5007E] inline-block px-2 transform -skew-x-12">
        Mockup Gallery
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg">
          <h3 className="text-black text-lg font-bold mb-2">Selected Character</h3>
          <div className="relative h-40 w-full">
            <Image
              src={character?.image || '/placeholder.svg?height=160&width=160&text=No+Character'}
              alt={character?.name || 'No character selected'}
              layout="fill"
              objectFit="contain"
            />
          </div>
          <p className="text-black mt-2 text-center">{character?.name || 'No character selected'}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg">
          <h3 className="text-black text-lg font-bold mb-2">Selected Branding</h3>
          <div className="grid gap-4">
            <div className="relative h-24 bg-gray-100 rounded flex items-center justify-center overflow-hidden">
              <Image
                src={logo?.image || '/placeholder.svg?height=80&width=80&text=No+Logo'}
                alt="Selected Logo"
                layout="fill"
                objectFit="contain"
              />
            </div>
            <div className="relative h-24 bg-gray-100 rounded flex items-center justify-center overflow-hidden">
              <Image
                src={font?.image || '/placeholder.svg?height=80&width=80&text=No+Font'}
                alt="Selected Font"
                layout="fill"
                objectFit="contain"
              />
            </div>
            <div className="relative h-24 bg-gray-100 rounded flex items-center justify-center overflow-hidden">
              <Image
                src={colors?.image || '/placeholder.svg?height=80&width=80&text=No+Colors'}
                alt="Selected Colors"
                layout="fill"
                objectFit="contain"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-xl font-bold mb-4 uppercase">Preview Mockups</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {mockups.map((mockup) => (
            <div key={mockup.id} className="bg-white p-4 rounded-lg transform hover:scale-105 transition-transform">
              <div className="relative h-48 w-full mb-2">
                <Image
                  src={mockup.image}
                  alt={mockup.title}
                  layout="fill"
                  objectFit="cover"
                  className="rounded"
                />
              </div>
              <h4 className="text-black font-bold text-lg mb-1">{mockup.title}</h4>
              <p className="text-gray-600 text-sm">{mockup.description}</p>
            </div>
          ))}
        </div>
      </div>
      </div>
    </div>
  )
}